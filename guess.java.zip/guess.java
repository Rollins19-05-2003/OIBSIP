import java.util.Random;
import java.util.Scanner;

public class guess {
    public static void main(String[] args) {
        System.out.println("\n");
        System.out.println("----- Welcome to guess the number game -----");
        System.out.println("You will get maximum 10 chances to guess the correct number");

        Random rand = new Random();
        int randomNumber = rand.nextInt(100) + 1;
        Scanner sc = new Scanner(System.in);

        int attempt = 0, points;
        int maxAttempt = 10;

        System.out.println("\n");
        while (maxAttempt > 0) {
            System.out.print("------Enter your guess ----- : ");
            int playerNumber = sc.nextInt();
            attempt++;
            maxAttempt--;

            if (playerNumber == randomNumber) {
                System.out.println("\nHurray!! its a correct guess");
                System.out.println("You took " + attempt + " attempts");
                System.out.println("-----Your point is " + (10 - attempt) + " out of 10 ----- ");
                break;
            } else if (playerNumber > randomNumber) {
                System.out.println("Enter a smaller number");
                System.out.println("You have " + maxAttempt + " chances left");
            } else {
                System.out.println("Enter a greater number");
                System.out.println("you have " + maxAttempt + " chances left");
            }
            if (maxAttempt == 0) {
                System.out.println("Opps!! You are out of chances...");
            }
        }
        sc.close();
    }
}